class WebsiteController < ApplicationController
  def index
  @user = User.new
  end
end
