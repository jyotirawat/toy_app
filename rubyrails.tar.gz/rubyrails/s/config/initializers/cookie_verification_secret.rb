# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '2f9f2d3f2a6d5b37f60709c57e9fa7f56b7be398203dfd8b3125de95fc9b1f8c346e861b6b1e7a3dbd5be01d38baefc782a8849c49b9a8e09908ff6dfa6e9594';
